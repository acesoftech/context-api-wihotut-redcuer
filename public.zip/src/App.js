import React from 'react';
import UCProvider from './contexts/UserContext';
import Dashboard from './components/Dashboard';

function App() { 
    return (
    <UCProvider>
        <Dashboard/>
    </UCProvider>
    );

}
export default App;