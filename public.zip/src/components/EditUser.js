import React,{useContext,useState,useEffect} from 'react';
import { UserContext } from '../contexts/UserContext';
import { useNavigate, useParams } from "react-router-dom";

const EditUser = (props) => {
  let history = useNavigate();
  const {fetchUserall,updateUser} = useContext(UserContext);
  const {id} =useParams();

  useEffect( () => {
    window.scrollTo(0, 0);
    fetchUser(id);
  }, []); 

  const [isfetchuser, setfetchuser] = useState(false);


  const fetchUser = async (ids) => {
    try {
      const fetchUserlist = await fetchUserall(ids);
      if(fetchUserlist.success === true){
        setuserInfo({
          ...userInfo,
          name:fetchUserlist.editlist.user_name,
          email:fetchUserlist.editlist.user_email,
        });
        setfetchuser(true);
      }
    } catch (error) { throw error;}    
  }

  const [userInfo, setuserInfo] = useState({
    name: '',
    email: '',
  });
  const onChangeValue = (e) => {
    setuserInfo({
      ...userInfo,
      [e.target.name]:e.target.value
    });
  } 
 
  // Update into the Database.
  const editUser = async(event) => {
    try {
      event.preventDefault();
      event.persist();
      const data = await updateUser(userInfo,id);
      if(data.success === true){
        history(`/`);
        event.target.reset();
        return;
      }
    } catch (error) { throw error;}    
  };
 
return ( <>
  {isfetchuser === true && 
    <form className="insertForm" onSubmit={editUser}>
      <h2>Edit User</h2>
      <label htmlFor="_name">Name</label>
      <input
        type="text"
        id="_name"
        name="name"
        value={userInfo.name}
        onChange={onChangeValue}
        placeholder="Enter name"
        autoComplete="off"
        required
      />
      <label htmlFor="_email">Email</label>
      <input
        type="email"
        id="_email"
        name="email"
        value={userInfo.email}
        onChange={onChangeValue}
        placeholder="Enter email"
        autoComplete="off"
        required
      />
      <input type="submit" value="Update User" />
    </form> 
  }
</> );
};
export default EditUser;