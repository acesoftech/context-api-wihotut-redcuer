import React from 'react';
import {BrowserRouter as Router,Routes,Route} from "react-router-dom";
import Home from './Home';
import AddUser from './AddUser';
import EditUser from './EditUser';

function Dashboard() {
  return (
    <div className="App">
      <Router>
        <Routes> 
          <Route exact path="/" element={<Home/>}/>
          <Route exact path="/add-user" element={<AddUser/>}/>
          <Route exact path="/edit-user/:id" element={<EditUser/>}/>
        </Routes>
      </Router>      
    </div>
  );
}
export default Dashboard;