import React,{useContext,useState} from 'react';
import { UserContext } from '../contexts/UserContext';
import { useNavigate } from "react-router-dom";

const AddUser = () => {
  let history = useNavigate();
  const { insertUser } = useContext(UserContext);
  const [userInfo, setuserInfo] = useState({
    name: '',
    email: '',
  });
  const onChangeValue = (e) => {
    setuserInfo({
      ...userInfo,
      [e.target.name]:e.target.value
    });
  } 
  // Inserting a new user into the Database.
  const submitUser = async(event) => {
    try {
      event.preventDefault();
      event.persist();
      const data = await insertUser(userInfo);
      if(data.success === true){
        history(`/`);
        event.target.reset();
        return;
      }
    } catch (error) { throw error;}    
  };

return (
  <form className="insertForm" onSubmit={submitUser}>
    <h2> Add User </h2>
    <label htmlFor="_name">Full Name</label>
    <input
      type="text"
      id="_name"
      name="name"
      onChange={onChangeValue}
      placeholder="Enter name"
      autoComplete="off"
      required
    />
    <label htmlFor="_email">Email</label>
    <input
      type="email"
      id="_email"
      name="email"
      onChange={onChangeValue}
      placeholder="Enter email"
      autoComplete="off"
      required
    />
    <input type="submit" value="Add User" />
  </form>
);
};

export default AddUser;