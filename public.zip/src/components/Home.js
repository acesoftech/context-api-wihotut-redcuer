import React from 'react';
import {Link} from "react-router-dom";
import UserList from "./UserList";

const Home = () => {
  return (
    <div>
      <h1>Context API CRUD with PHP MySQL Backend</h1>
      <div className="wrapper">
        <section className="left-side">
          <Link to={`/add-user`}> Add New User </Link>
        </section>
        <section className="right-side">
          <UserList />
        </section>
      </div>
    </div>
  )
}
export default Home
