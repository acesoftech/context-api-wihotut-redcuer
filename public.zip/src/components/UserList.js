import React,{useContext,useState,useEffect} from 'react';
import { UserContext } from '../contexts/UserContext';
import { Link } from "react-router-dom";

const ListUsers = () => {
  const {userlistall,deleteUserall} = useContext(UserContext);
  useEffect( () => {
    window.scrollTo(0, 0);
    alluser();
  }, []); 


  const [isuser, setuser] = useState([]);

  const alluser = async (ids) => {
    try {
      const allusers = await userlistall(ids);
      console.log(allusers);
      if(allusers.success === true){
          setuser(allusers.fetchusers);
      }
    } catch (error) { throw error;}    
  }

  const deleteConfirm = (id) => {
    if (window.confirm("Are you sure?")) {
      deleteUser(id);
    }
  };


  const deleteUser = async (id) => {
    try {
      const deleteUser = await deleteUserall(id);
      if(deleteUser.success === true){
        setuser([]);
        alluser();
      }
    } catch (error) { throw error;}    
  }


return ( <>
  {isuser.map((item,index)=>(
    <div className="list" key={item.id}>
      <p>Full Name: {item.user_name}</p>
      <p>Email Id: {item.user_email}</p>
      <Link  to={`edit-user/${item.id}`} className="btn default-btn"> Edit </Link>
      <button className="btn red-btn" onClick={() => deleteConfirm(item.id)}> Delete </button>
    </div>
  ))}
</> );
};

export default ListUsers;