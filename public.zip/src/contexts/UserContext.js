import React, { createContext,Component } from "react";
import axios from 'axios';
export const UserContext = createContext();

// Define the base URL
const Axios = axios.create({
    baseURL: 'http://localhost/php-react/use-context-crud/',
});


const MyContextProvider = ({ children }) => {
  
  const userlistall = async () => {
    const userlistalls = await Axios.get(`client-all.php`);
    return userlistalls.data;
  };

  const deleteUserall = async (id) => {
    const deleteUseralls = await Axios.post(`client-delete.php`, {
      userid: id,
    });
    return deleteUseralls.data;
  };

  const insertUser = async (userInfo) => {
    const insertUsers = await Axios.post(`client-add.php`, {
      name: userInfo.name,
      email: userInfo.email,
    });
    return insertUsers.data;
  };

  const fetchUserall = async (id) => {
    const fetchUseralls = await Axios.post(`client-edit.php?userid=` + id);
    return fetchUseralls.data;
  };

  const updateUser = async (userInfo, id) => {
    const updateUsers = await Axios.post(`client-update.php`, {
      name: userInfo.name,
      email: userInfo.email,
      userid: id,
    });
    return updateUsers.data;
  };

  const contextValue = {
    userlistall,
    deleteUserall,
    insertUser,
    fetchUserall,
    updateUser,
  };

  return <UserContext.Provider value={contextValue}>{children}</UserContext.Provider>;
};

export default MyContextProvider;